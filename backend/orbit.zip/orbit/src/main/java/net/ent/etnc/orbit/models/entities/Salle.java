package net.ent.etnc.orbit.models.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import net.ent.etnc.orbit.models.commons.AbstractPersistableWithIdSetter;
import net.ent.etnc.orbit.models.enums.TypeSalle;
import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "SALLE",
        uniqueConstraints = @UniqueConstraint(name = "uk_SALLE_numSalle", columnNames = {"numSalle"}))
@EqualsAndHashCode(callSuper = false, of = {"numSalle"})
@ToString(callSuper = true, of = {"numSalle", "etage", "type"})
public class Salle extends AbstractPersistableWithIdSetter<Long> {
    
    @Getter 
    @Setter
    @NotNull(message = "numSalle ne doit pas être null")
    @NotEmpty(message = "numSalle ne doit pas être vide")
    @NotBlank(message = "numSalle doit contenir des caractères lisibles")
    @Length(min = 1, max = 10, message = "numSalle doit avoir entre 1 et 10 caractères")
    @Column(name = "num_salle", length = 10, nullable = false)
    private String numSalle;

    @Getter
    @Setter
    @NotNull(message = "etage ne doit pas être null")
    @NotEmpty(message = "etage ne doit pas être vide")
    @NotBlank(message = "etage doit contenir des caractères lisibles")
    @Length(min = 1, max = 5, message = "etage doit avoir entre 1 et 5 caractères")
    @Column(name = "etage", length = 5, nullable = false)
    private String etage;

    @Getter
    @Setter
    @NotNull(message = "type ne doit pas être null")
    @Enumerated(EnumType.STRING)
    @Column(name = "type",length = 20, nullable = false)
    private TypeSalle type;

}