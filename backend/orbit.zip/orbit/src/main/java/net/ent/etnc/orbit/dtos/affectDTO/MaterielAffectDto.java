package net.ent.etnc.orbit.dtos.affectDTO;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MaterielAffectDto {
}
